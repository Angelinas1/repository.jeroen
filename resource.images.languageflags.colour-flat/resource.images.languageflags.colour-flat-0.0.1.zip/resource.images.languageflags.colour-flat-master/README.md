# resource.images.languageflags.colour-flat
